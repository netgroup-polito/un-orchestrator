#!/bin/bash

#$1 port numbers
#$2...$n port names

set -x

#Check if script was execute with root privileges
if (( $EUID != 0 ))
then
    echo "[$0] This script must be executed with ROOT privileges"
    exit 0
fi

port=2
for ((i=0; i<$1; i++))
do	
	ethtool --offload ${!port} rx off tx off
	ethtool -K ${!port} gso off
	let "port+=1"	
done
