#include "tcpserver.h"

using namespace rofl::examples;

void
signal_handler(int signal) {
	switch (signal) {
	case SIGINT: {

	} break;
	}
}


