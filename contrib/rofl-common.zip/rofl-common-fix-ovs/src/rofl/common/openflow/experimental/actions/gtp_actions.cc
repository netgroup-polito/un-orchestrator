/*
 * gtp_actions.cc
 *
 *  Created on: 02.08.2013
 *      Author: andreas
 */

#include "rofl/common/openflow/experimental/actions/gtp_actions.h"

using namespace rofl::openflow::experimental::gtp;





