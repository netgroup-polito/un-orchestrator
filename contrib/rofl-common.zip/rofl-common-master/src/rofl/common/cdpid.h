/*
 * cdpid.h
 *
 *  Created on: 05.08.2014
 *      Author: andreas
 */

#ifndef CDPID_HPP_
#define CDPID_HPP_

#include <inttypes.h>

namespace rofl {

typedef uint64_t cdpid;
};

#endif /* CDPID_HPP_ */
