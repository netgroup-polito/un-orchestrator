/*
 * gre_actions.cc
 *
 *  Created on: 23.09.2014
 *      Author: andreas
 */

#include "rofl/common/openflow/experimental/actions/gre_actions.h"

using namespace rofl::openflow::experimental::gre;
