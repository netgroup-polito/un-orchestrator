/*
 * gre_matches.cc
 *
 *  Created on: 23.09.2014
 *      Author: andreas
 */

#include <rofl/common/openflow/experimental/matches/gre_matches.h>

using namespace rofl::openflow::experimental::gre;
