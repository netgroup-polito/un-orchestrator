/*
 * cdptid.h
 *
 *  Created on: 19.04.2014
 *      Author: andreas
 */

#ifndef CDPTID_H_
#define CDPTID_H_

namespace rofl {

/**
 * @ingroup common_devel_workflow
 * @brief	rofl-common's internal remote datapath handle.
 */
typedef unsigned int cdptid;

}; // end of namespace

#endif /* CDPTID_H_ */
