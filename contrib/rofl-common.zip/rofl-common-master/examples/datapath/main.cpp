#include "datapath.hpp"

int main(int argc, char **argv) {
  rofl::examples::datapath dpt;

  return dpt.run(argc, argv);
}
