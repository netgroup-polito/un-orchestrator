#include "tcpclient.h"

int main(int argc, char **argv) {
  rofl::examples::tcpclient client;

  return client.run(argc, argv);
}
