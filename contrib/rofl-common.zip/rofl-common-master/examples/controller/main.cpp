#include "controller.hpp"

int main(int argc, char **argv) {
  rofl::examples::controller ctl;

  return ctl.run(argc, argv);
}
