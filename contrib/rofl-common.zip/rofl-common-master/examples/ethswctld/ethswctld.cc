#include "cetherswitch.h"

int
main(int argc, char** argv)
{
	return rofl::examples::ethswctld::cetherswitch::run(argc, argv);
}

