/*
 * cfib.cc
 *
 *  Created on: 15.07.2013
 *      Author: andreas
 */

#include "cfibtable.h"

using namespace rofl::examples::ethswctld;

std::map<rofl::cdptid, cfibtable *> cfibtable::fibtables;
